## 8.0.1  *May 2016*

  * Bundled with GHC 8.0.1

  * Initial version
