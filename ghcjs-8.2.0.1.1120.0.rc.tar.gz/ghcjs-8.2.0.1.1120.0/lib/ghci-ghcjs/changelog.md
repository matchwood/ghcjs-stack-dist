## 8.2.2 Nov 2017

  * Bundled with GHC 8.2.2

## 8.2.1 Jul 2017

  * Bundled with GHC 8.2.1

  * Add support for StaticPointers in GHCi (#12356)

  * Move Typeable Binary instances to `binary` package

## 8.0.1  *Feb 2016*

  * Bundled with GHC 8.0.1

  * Initial version
