// Out-of-line versions of all the inline functions from HsGDI.h
#define INLINE  /* nothing */
#include "HsGDI.h"
